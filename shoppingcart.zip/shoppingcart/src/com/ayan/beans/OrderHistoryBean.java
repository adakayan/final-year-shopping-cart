package com.ayan.beans;
import java.io.Serializable;
import java.sql.Date;

public class OrderHistoryBean implements Serializable {
	private String transactionId;
	private String productName;
	private Date purchaseDate;
	private int quantity;
	private Double amount;
	private int shipped;
	
	public OrderHistoryBean(String transactionId,String productName,Date purchaseDate, int quantity, Double amount,int shipped)
	{
		super();
		this.transactionId=transactionId;
		this.amount=amount;
		this.productName=productName;
		this.purchaseDate=purchaseDate;
		this.shipped=shipped;
		this.quantity=quantity;
	}
	public OrderHistoryBean()
	{
		super();
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Date getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public int getShipped() {
		return shipped;
	}
	public void setShipped(int shipped) {
		this.shipped = shipped;
	}
}
