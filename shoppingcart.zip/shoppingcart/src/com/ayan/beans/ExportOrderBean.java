package com.ayan.beans;

import java.sql.Timestamp;

import com.opencsv.bean.CsvBindByPosition;

public class ExportOrderBean {
	@CsvBindByPosition(position=0)
	String transId ;
	@CsvBindByPosition(position=1)
	String prodId ;
	@CsvBindByPosition(position=3)
	int quantity;
	@CsvBindByPosition(position=4)
	String userId ;
	@CsvBindByPosition(position=5)
	String userAddr ;
	@CsvBindByPosition(position=2)
	String prodName;
	@CsvBindByPosition(position=6)
	Timestamp transDate;
	@CsvBindByPosition(position=7)
	Double amount;
	public ExportOrderBean(String transId ,String prodId,String prodName,int quantity,String userId ,Double amount,Timestamp timestamp,String userAddr)
	{
		super();
		this.transId=transId;
		this.prodId=prodId;
		this.prodName=prodName;
		this.quantity=quantity;
		this.userAddr=userAddr;
		this.transDate=timestamp;
		this.amount=amount;
		this.userId=userId;
		
	}
	@Override
    public String toString() 
    { 
		return "ExportOrderBean[TRANSACTION_ID="+transId+",PRODUCT_ID="+prodId+", PRODUCT_NAME="+prodName+",QUANTITY="+quantity+",USER_ID="+userId+",USER_ADDRESS="+userAddr+",TRANSACTION_DATE="+transDate+",AMOUNT="+amount+"]";
    }
	public String getTransId() {
		return transId;
	}
	public void setTransId(String transId) {
		this.transId = transId;
	}
	public String getProdId() {
		return prodId;
	}
	public void setProdId(String prodId) {
		this.prodId = prodId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserAddr() {
		return userAddr;
	}
	public void setUserAddr(String userAddr) {
		this.userAddr = userAddr;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public Timestamp getTransDate() {
		return transDate;
	}
	public void setTransDate(Timestamp transDate) {
		this.transDate = transDate;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}

}
