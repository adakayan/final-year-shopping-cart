package com.ayan.utility;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class IDUtil {

	public static String generateId() {
		String pId = null;
		int currId=getCurrentId();
		System.out.println(currId);
		pId = "P"+String.valueOf(currId);
		return pId;
	}
	
	public static String generateTransId() {
		String tId = null;
		int currId=getCurrentId();
		System.out.println(currId);
		tId = "T"+String.valueOf(currId);
		return tId;
	}
	private static int getCurrentId()
	{
         int currentId = 0;
		
		Connection  con = DBUtil.provideConnection();
		
		PreparedStatement ps = null;
		
		ResultSet rs = null;
		
		try {
			ps = con.prepareStatement("select currentid from idmanager order by id desc limit 1;");
			rs = ps.executeQuery();
			
			if(rs.next() && rs!=null)
				currentId = rs.getInt("currentid");
			rs=null;
			System.out.println(currentId);
			int dbcurr=currentId+1;
			ps=con.prepareStatement("update idmanager set currentid=? where id=?;");
			ps.setInt(1,dbcurr);
			ps.setInt(2,2);
			int k=ps.executeUpdate();
			System.out.println(k);
		} catch (SQLException e) {
			currentId = 0;
			e.printStackTrace();
		}
		
		DBUtil.closeConnection(con);
		DBUtil.closeConnection(ps);
		DBUtil.closeConnection(rs);
		
		
		return currentId;	
	}
	/*private static void createRandomInteger(int aStart, long aEnd, Random aRandom){
	    if ( aStart > aEnd ) {
	      throw new IllegalArgumentException("Start cannot exceed End.");
	    }
	    //get the range, casting to long to avoid overflow problems
	    long range = aEnd - (long)aStart + 1;
	    System.out.println("range>>>>>>>>>>>"+range);
	    // compute a fraction of the range, 0 <= frac < range
	    long fraction = (long)(range * aRandom.nextDouble());
	    System.out.println("fraction>>>>>>>>>>>>>>>>>>>>"+fraction);
	    long randomNumber =  fraction + (long)aStart;    
	    System.out.println("Generated : " + randomNumber);

	  }*/
}
