package com.ayan.utility;

public class GenerateInvoice {

}
