package com.ayan.utility;
import java.io.FileWriter; 
import java.util.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.ayan.beans.ExportOrderBean;
import com.ayan.beans.OrderBean;
import com.ayan.beans.ProductBean;
import com.ayan.beans.TransactionBean;
import com.ayan.dao.OrderDaoImpl;
import com.ayan.dao.ProductDaoImpl;
import com.ayan.dao.TransDaoImpl;
import com.ayan.dao.UserDaoImpl;
  
public class BeanToCSV {
	  //Delimiter used in CSV file
    private static final String COMMA_DELIMITER = ",";
    private static final String NEW_LINE_SEPARATOR = "\n";
     
    //CSV file header
    private static final String FILE_HEADER = "TRANSACTION_ID, PRODUCT_ID,PRODUCT_NAME,QUANTITY,USER_ID,USER_ADDRESS,TRANSACTION_DATE,AMOUNT";
    public int createCSV() 
    { 
        final String CSV_LOCATION = "D:/OrdersCSV/Orders.csv"; 
        FileWriter fileWriter = null;
        int res=0;
        
        try {
            fileWriter = new FileWriter(CSV_LOCATION);
 
            //Write the CSV file header
            fileWriter.append(FILE_HEADER.toString());
             
            //Add a new line separator after the header
            fileWriter.append(NEW_LINE_SEPARATOR);
            
            OrderDaoImpl orderdao = new OrderDaoImpl();

    		List<OrderBean> orders = new ArrayList<OrderBean>();
    		orders = orderdao.getAllOrders();
    		List<ExportOrderBean> exportOrderList=new ArrayList<ExportOrderBean>();
    		
    		for(OrderBean order: orders){
    			if(order.getShipped()==1)
    			{
    			String transId = order.getTransactionId();
    			String prodId = order.getProductId();
    			int quantity = order.getQuantity();
    			TransactionBean transbean = new TransDaoImpl().getTransactionBean(transId);
    			Timestamp transactionDate=transbean.getTransDateTime();
    			String userAddr = new UserDaoImpl().getUserAddr(transbean.getUserName());
    			userAddr=userAddr.replaceAll(","," ");
    			System.out.println(userAddr);
    			ProductBean product=new ProductDaoImpl().getProductDetails(prodId);
    			String prodName=product.getProdName();
    			ExportOrderBean exportOrderBean=new ExportOrderBean(transId ,prodId,prodName,quantity,transbean.getUserName(),transbean.getTransAmount(),transactionDate,userAddr);
    			exportOrderList.add(exportOrderBean);
    			exportOrderBean=null;
    			}
    		}
    		
    		         System.out.println(exportOrderList);
    	             
    	            //Write a new student object list to the CSV file
    	            for (ExportOrderBean exportOrderBean : exportOrderList) {
    	                fileWriter.append(String.valueOf(exportOrderBean.getTransId()));
    	                fileWriter.append(COMMA_DELIMITER);
    	                fileWriter.append(exportOrderBean.getProdId());
    	                fileWriter.append(COMMA_DELIMITER);
    	                fileWriter.append(exportOrderBean.getProdName());
    	                fileWriter.append(COMMA_DELIMITER);
    	                fileWriter.append(String.valueOf(exportOrderBean.getQuantity()));
    	                fileWriter.append(COMMA_DELIMITER);
    	                fileWriter.append(exportOrderBean.getUserId());
    	                fileWriter.append(COMMA_DELIMITER);
    	                fileWriter.append(exportOrderBean.getUserAddr());
    	                fileWriter.append(COMMA_DELIMITER);
    	                Date date=exportOrderBean.getTransDate();
    	                String strDate = new SimpleDateFormat("yyyy-MM-dd").format(date);
    	                fileWriter.append(strDate);
    	                System.out.println(strDate);
    	                fileWriter.append(COMMA_DELIMITER);
    	                fileWriter.append(String.valueOf(exportOrderBean.getAmount()));
    	                fileWriter.append(NEW_LINE_SEPARATOR);
    	            }
    	            
    	            res=1;
    	             
    	        } catch (Exception e) {
    	            System.out.println("Error in CsvFileWriter !!!");
    	            e.printStackTrace();
    	            res=0;
    	        } finally {
    	             
    	            try {
    	                fileWriter.flush();
    	                fileWriter.close();
    	            } catch (IOException e) {
    	                System.out.println("Error while flushing/closing fileWriter !!!");
    	                e.printStackTrace();
    	            }
    	             
    	        }
        return res;
    }
}