package com.ayan.dao;

import java.util.List;

import com.ayan.beans.OrderBean;
import com.ayan.beans.OrderHistoryBean;
import com.ayan.beans.TransactionBean;

public interface OrderDao {
	
	public String paymentSuccess(String userName,double paidAmount);

	public boolean addOrder(OrderBean order);
	
	public boolean addTransaction(TransactionBean transaction);
	
	public int countSoldItem(String prodId);
	public int shipOrder(String transId);
	public List<OrderBean> getAllOrders();

	public List<OrderHistoryBean> getOrderHistory(String username);
}
