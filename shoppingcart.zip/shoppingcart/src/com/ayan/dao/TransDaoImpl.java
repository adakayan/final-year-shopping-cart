package com.ayan.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.ayan.beans.TransactionBean;
import com.ayan.utility.DBUtil;

public class TransDaoImpl implements TransDao{

	@Override
	public String getUserId(String transId) {
		String userId = "";
		
		Connection con = DBUtil.provideConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			
			ps = con.prepareStatement("select username from transactions where transid=?");
			
			ps.setString(1, transId);
			
			rs = ps.executeQuery();
			
			if(rs.next())
				userId = rs.getString(1);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	
		
		return userId;
	}
	
	@Override
	public TransactionBean getTransactionBean(String transId) {
		TransactionBean transBean=new TransactionBean();
		
		Connection con = DBUtil.provideConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			
			ps = con.prepareStatement("select * from transactions where transid=?");
			
			ps.setString(1, transId);
			
			rs = ps.executeQuery();
			
			if(rs.next())
			{
				transBean.setTransactionId(rs.getString(1));
				transBean.setUserName(rs.getString(2));
				transBean.setTransDateTime(rs.getTimestamp(3));
				transBean.setTransAmount(rs.getDouble(4));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	
		
		return transBean;
	}
	
}
