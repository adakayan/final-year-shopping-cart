package com.ayan.dao;

import com.ayan.beans.TransactionBean;

public interface TransDao {

	public String getUserId(String transId);
	public TransactionBean getTransactionBean(String transId);
}
